public class Plumber:IPlumber
{
   public void FixPipe(ref int numberOfCrashes)
    {
        numberOfCrashes--;
    }

}